import Link from 'next/link'
import Head from 'next/head'
import Layout1 from '@/components/Layout1';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import Admins from '/administradores.json';
import libraryData from '/library.json';




const Principal = () => {
    const router = useRouter();
    const { usuario } = router.query;

    // Buscar el administrador por el usuario
    let administradorEncontrado = null;

    // Recorre el objeto de administradores usando forEach
    Object.keys(Admins).forEach(clave => {
        const admin = Admins[clave];
        if (admin.correo === usuario) {
            administradorEncontrado = admin;
        }
    });

    // Obtén el nombre del administrador
    let nombreDelAdministrador = administradorEncontrado ? administradorEncontrado.nombre : 'anonomous';
    let primernombre = "";  // Inicializamos primernombre como una cadena vacía

    // Verificamos si nombreDelAdministrador no es nulo o indefinido antes de procesarlo
    if (nombreDelAdministrador) {
        const nombreAdministradorArray = nombreDelAdministrador.split(' '); // Dividimos la cadena en palabras
        primernombre = nombreAdministradorArray[0]; // Obtenemos el primer elemento del array
    }


    // Estado para controlar el valor del input
    const [inputText, setInputText] = useState('');

    // Estado para almacenar las coincidencias basadas en el texto del input
    const [coincidencias, setCoincidencias] = useState([]);

    // Estado para rastrear la página actual de resultados
    const [paginaActual, setPaginaActual] = useState(1);

    // Número de resultados por página
    const resultadosPorPagina = 3;
    // Función para buscar coincidencias cuando el texto del input cambia
    useEffect(() => {
        if (inputText.trim() === '') {
            setCoincidencias([]); // Si el input está vacío, muestra ninguna coincidencia
        } else {
            // Filtra las coincidencias basadas en el texto del input
            const coincidenciasFiltradas = libraryData.filter(libro =>
                libro.titulo.toLowerCase().includes(inputText.toLowerCase())
            );
            setCoincidencias(coincidenciasFiltradas);
            // Al cambiar el texto del input, vuelve a la página 1
            setPaginaActual(1);
        }
    }, [inputText]);

    // Función para ir a la página siguiente de resultados
    const irAPaginaSiguiente = () => {
        if ((paginaActual + 1) * resultadosPorPagina <= coincidencias.length) {
            setPaginaActual(paginaActual + 1);
        }
    };

    // Función para ir a la página anterior de resultados
    const irAPaginaAnterior = () => {
        if (paginaActual > 1) {
            setPaginaActual(paginaActual - 1);
        }
    };

    // Calcula los índices de inicio y fin para mostrar los resultados de la página actual
    const indiceInicio = (paginaActual - 1) * resultadosPorPagina;
    const indiceFin = indiceInicio + resultadosPorPagina;


    const doEscribir = async () => {
        window.location.href = `/blog/admin/${usuario}/paginaInsertarNuevoLibroAdmin`;
    }
    return (
        <>
            <Layout1 content={
                <>
                    <div className="contenidoizquierda">
                        <div className="opciones">
                            <ul>
                                <li><Link href={`/blog/admin/${usuario}/paginaPrincipalAdmin`}>Inicio</Link></li>
                                <li><Link href={`/blog/admin/${usuario}/paginaPerfilAdmin`}>Perfil</Link></li>
                                <li><Link href={`/blog/admin/${usuario}/paginaResultadosAdmin`}>Bibliotecas</Link></li>
                            </ul>
                        </div>
                        <p className="version">Biblio v1.0.1-Alpha</p>
                    </div>
                    <div className="seccion-titulo-resultados">
                        <div className="titulo">
                            <h2>Biblioteca</h2>
                        </div>
                        <button onClick={doEscribir}>Añadir un nuevo recurso</button>
                    </div>
                    <div className="linea2"></div>
                    <div className="casilla-para-escribir">
                        <label className="form-label-3" htmlFor="contrasena">
                            Ingresa la palabra clave
                            <div className="icono">
                                <img src="/Icon.png" alt="Icono" />
                            </div>
                        </label>
                        <input
                            className="form-input-3"
                            type="text"
                            id="recurso"
                            name="recurso"
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            placeholder="Buscar por título"
                        />
                    </div>
                    <div className="seccion-rectangular-gris">
                        {coincidencias.slice(indiceInicio, indiceFin).map((libro, index) => (
                            <div className="bloque-libro" key={index}>
                                <div className="titulo-libro">
                                    <h3>{libro.titulo}</h3>
                                </div>
                                <div className="imagenes-libro">
                                    <img src="/media.png" alt="Icono XD" className="icono-xd" />
                                    <img src={libro["imagen-portada-url"]} alt="Portada del libro" className="portada-libro" />
                                </div>
                                <div className="informacion-libro">
                                    <p><b>ISBN:</b> {libro.ISBN}</p>
                                    <p><b>Autor:</b> <u>{libro.autor}</u></p>
                                    <p><b>Editorial:</b> {libro.editorial}</p>
                                </div>
                                <button>Reservar</button>
                            </div>
                        ))}
                    </div>

                    <div className="paginacion">
                        <button onClick={irAPaginaAnterior} disabled={paginaActual === 1}>
                            {'<'}
                        </button>
                        <button onClick={irAPaginaSiguiente} disabled={paginaActual === (Math.ceil((coincidencias.length)/3))-1}>
                            {'>'}
                        </button>
                    </div>

                </>
            } />
        </>
    )
}

export default Principal;
