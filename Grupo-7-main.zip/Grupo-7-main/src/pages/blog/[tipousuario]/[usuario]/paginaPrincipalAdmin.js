import Link from 'next/link'
import Head from 'next/head'
import Layout from '@/components/Layout'
import { useRouter } from 'next/router';
import Admins from '/administradores.json';

const Principal = () => {
  const router = useRouter();
  const { usuario } = router.query;

  // Buscar el administrador por el usuario
  let administradorEncontrado = null;

  // Recorre el objeto de administradores usando forEach
  Object.keys(Admins).forEach(clave => {
    const admin = Admins[clave];
    if (admin.correo === usuario) {
      administradorEncontrado = admin;
    }
  });

  // Obtén el nombre del administrador
  let nombreDelAdministrador = administradorEncontrado ? administradorEncontrado.nombre: 'anonomous';
  let primernombre="";
  let pos = 0;
  while(nombreDelAdministrador[pos] !== ' '){
     primernombre =  primernombre + nombreDelAdministrador[pos];
     pos++;
  }
  return (
    <>
      <Layout content={
        <>
          <div className="contenidoizquierda">
            <div className="opciones">
              <ul>
                <li><Link href={`/blog/admin/${usuario}/paginaPrincipalAdmin`}>Inicio</Link></li>
                <li><Link href={`/blog/admin/${usuario}/paginaPerfilAdmin`}>Perfil</Link></li>
                <li><Link href={`/blog/admin/${usuario}/paginaResultadosAdmin`}>Bibliotecas</Link></li>
              </ul>
            </div>
            <p className="version">Biblio v1.0.1-Alpha</p>
          </div>
          <div className="seccion-titulo">
            <h2>Bienvenido, {primernombre}!</h2>
          </div>
          <div className="linea"></div>
          <div className="seccion-igual-1"></div>
          <div className="seccion-igual-2"></div>
        </>
      } />
    </>
  )
}

export default Principal;
