import Link from 'next/link';
import Head from 'next/head';
import Layout1 from '@/components/Layout1';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import Admins from '/administradores.json';
import libraryData from '/library.json';

const Principal = () => {
    const router = useRouter();
    const { usuario } = router.query;
    const { busqueda, checkboxes } = router.query;

    // Convierte los valores de los checkboxes en un objeto booleano
    const checkboxesObj = checkboxes
        ? JSON.parse(checkboxes)
        : { titulo: false, autor: false, serie: false, isbn: false };


    const [coincidencias, setCoincidencias] = useState([]);

    const [paginaActual, setPaginaActual] = useState(1);

    const resultadosPorPagina = 3;

    useEffect(() => {
        if (busqueda && busqueda.trim() !== '') {
            // Filtra las coincidencias basadas en la variable "busqueda"
            const coincidenciasFiltradas = libraryData.filter(libro =>
                libro.titulo.toLowerCase().includes(busqueda.toLowerCase())
            );
            setCoincidencias(coincidenciasFiltradas);
            // Al cambiar la variable "busqueda", vuelve a la página 1
            setPaginaActual(1);
        } else {
            // Si la variable "busqueda" está vacía, muestra ninguna coincidencia
            setCoincidencias([]);
        }
    }, [busqueda]);

    const irAPaginaSiguiente = () => {
        if ((paginaActual + 1) * resultadosPorPagina <= coincidencias.length) {
            setPaginaActual(paginaActual + 1);
        }
    };

    const irAPaginaAnterior = () => {
        if (paginaActual > 1) {
            setPaginaActual(paginaActual - 1);
        }
    };

    // Calcula los índices de inicio y fin para mostrar los resultados de la página actual
    const indiceInicio = (paginaActual - 1) * resultadosPorPagina;
    const indiceFin = indiceInicio + resultadosPorPagina;

    const doVolver = async () => {
        window.location.href = `/blog/admin/${usuario}/paginaResultadosAlumno`;
    };

    return (
        <>
            <Layout1
                content={
                    <>
                        <div className="contenidoizquierda">
                            <div className="opciones">
                                <ul>
                                    <li>
                                        <Link href={`/blog/admin/${usuario}/paginaPrincipalAlumno`}>Principal</Link>
                                    </li>
                                    <li>
                                        <Link href={`/blog/admin/${usuario}/paginaPerfilAlumno`}>Perfil</Link>
                                    </li>
                                    <li>
                                        <Link href={`/blog/admin/${usuario}/citasAlumno`}>Citas</Link>
                                    </li>
                                </ul>
                            </div>
                            <p className="version">Biblio v1.0.1-Alpha</p>
                        </div>
                        <div className="seccion-titulo-resultados">
                            <div className="titulo">
                                <h2>Búsqueda - Resultados</h2>
                            </div>
                            <button onClick={doVolver}>Volver a buscar</button>
                        </div>
                        <div className="linea2"></div>
                        <div className="seccion-info-busqueda">
                            <div className="titulo">
                                <h3>Resultados de la búsqueda:</h3>
                            </div>
                            <button>Ver mis reservas</button>
                        </div>
                        <div className="seccion-rectangular-gris">
                            {coincidencias.slice(indiceInicio, indiceFin).map((libro, index) => (
                                <div className="bloque-libro" key={index}>
                                    <div className="titulo-libro">
                                        {checkboxesObj.titulo && <h3>{libro.titulo}</h3>}
                                    </div>
                                    <div className="imagenes-libro">
                                        <img src="/media.png" alt="Icono XD" className="icono-xd" />
                                        <img src={libro["imagen-portada-url"]} alt="Portada del libro" className="portada-libro" />
                                    </div>
                                    <div className="informacion-libro">
                                        {checkboxesObj.autor && <p><b>Autor:</b> <u>{libro.autor}</u></p>}
                                        {checkboxesObj.serie && <p><b>Serie:</b> {libro.serie}</p>}
                                        {checkboxesObj.isbn && <p><b>ISBN:</b> {libro.ISBN}</p>}
                                        <button>Reservar</button>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="paginacion-2">
                            <button onClick={irAPaginaAnterior} disabled={paginaActual === 1}>
                                {'<'}
                            </button>
                            <button
                                onClick={irAPaginaSiguiente}
                                disabled={paginaActual === Math.ceil(coincidencias.length / resultadosPorPagina) - 1}
                            >
                                {'>'}
                            </button>
                        </div>
                    </>
                }
            />
        </>
    );
};

export default Principal;
