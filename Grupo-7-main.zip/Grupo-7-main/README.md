# Título del Proyecto

Proyecto del GRUPO 7

## Integrantes del Grupo

- Arturo Aaron Silvera Pocco
- Marcelo Cabrejos Benites
- Roberto Carlos Lopez Jauregui
- Alessandro Ledesma
- Natalia Perez
